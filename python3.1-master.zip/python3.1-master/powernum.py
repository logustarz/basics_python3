l,o=input().split()
l=int(l)
o=int(o)
print(l**o)
