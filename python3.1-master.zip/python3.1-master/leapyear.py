logu=int(input())
if logu%4==0:
    print("yes")
else:
    print("no")
