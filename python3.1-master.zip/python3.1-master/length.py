logu=input()
print(len(logu))
