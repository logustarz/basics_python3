l,o=map(int,input().split())
g=k
u=0
pd=[]
pd=list(map(int,input().strip().split()))[:l]
for i in range(0,g):
  u=u + pd[i]
print(u)
