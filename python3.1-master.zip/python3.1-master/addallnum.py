n=int(input())
l=0
o=0
while l<n:
    l+=1
    g=int(input())
    o=o+g
print(o)
