def lo(l):
    str=""
    for i in l:
        str=i+str
    return str
l=input()

print(lo(l))
