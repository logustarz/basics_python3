l,o,g=map(int,input().split())
if l>o:
    if l>g:
        print(l)
    elif l<g:
        print(g)
elif o>g:
    print(o)
else:
    print(g)
