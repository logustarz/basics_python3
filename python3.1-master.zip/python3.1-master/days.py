while 0==0:
    l=input()
    if(l=="sunday" or l=="Sunday" or l=="saturday" or l=="Saturday"):
        print("yes")
    else:
        print("no")
