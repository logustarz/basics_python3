l=int(input())
if l>1:
    for o in range(2,l):
        if l%o==0:
            print("no")
            break
     else:
        print("yes")
else:
    print("no")
