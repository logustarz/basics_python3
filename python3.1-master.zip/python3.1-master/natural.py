l=int(input())
o=0
while l>0:
  o=o+l
  l-=l
print(o)
