l="Hello"
o=int(input())
g=0
while g<o:
    print(l,"")
    g=g+1
