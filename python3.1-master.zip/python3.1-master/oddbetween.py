l,o=input().split()
l=int(l)
o=int(o)
l=l+1
o=o-1
while l<=o:
    if l%2==0:
        l=l+1
    else:
        print(l,end=" ")
        l=l+1
