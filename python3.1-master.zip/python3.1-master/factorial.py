l=int(input())
if l<=20:
    logu=1
    for i in range(1,l+1):
        logu= logu*i
    print(logu)
