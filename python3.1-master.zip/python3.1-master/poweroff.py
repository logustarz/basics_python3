l,o=input().split()
l=int(l)
o=int(o)
z=o*o
if l==z:
    print("yes")
else:
    print("no")
