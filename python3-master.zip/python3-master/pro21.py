n=int(input())
l=(input().split())[0:n]
o=n//2
if n>3:
  if(o%2==0):
    print("yes")
  else:
    print("no")
else:
  if(n==3):
    print("yes")
  else:
    print("no")
