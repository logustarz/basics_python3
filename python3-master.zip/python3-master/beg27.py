l=input()
o=l.isnumeric()
if True==o:
  print("yes")
else:
  print("No")
