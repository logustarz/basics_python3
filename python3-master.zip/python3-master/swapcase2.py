log=input()
print(log.swapcase())
