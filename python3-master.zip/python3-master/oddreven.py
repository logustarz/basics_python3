l=int(input())
if l%2==0:
    print("Even")
else:
    print("Odd")
