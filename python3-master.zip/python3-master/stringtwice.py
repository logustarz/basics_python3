l,o=map(str,input().split())
o=int(o)
for m in range(o):
    print(l)
