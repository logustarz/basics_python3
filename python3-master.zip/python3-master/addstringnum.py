l,o=input().split()
logu=l+o
print(logu)
