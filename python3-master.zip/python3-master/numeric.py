l=input()
if(l.isnumeric())==True:
    print("yes")
else:
    print("no")
