l=int(input())
sum=0
while(l>0):
    r=l%10
    sum=sum+r*r
    l=l//10
print(sum)
