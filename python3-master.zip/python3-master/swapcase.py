logu=input()
print(logu.swapcase())
