ll=input()
if ((ll>="a" and ll<='z') or (ll>='A' and ll<='Z')):
    print("Alphabet")
else:
    print('No')


