l=int(input())
o=l
c=0
while o!=0:
  if(o/1000)>=1:
    c=c+1
    o=o-1000
  elif (o/500)>=1:
    c=c+1
    o=o-500
  elif (o/100)>=1:
    c=c+1
    o=o-100
  elif (o/50)>=1:
    c=c+1
    o=o-50
  elif (o/10)>=1:
    c=c+1
    o=o-10
  elif o<10:
    c=c+o
    o=o-o
print(c)
