l=int(input())
o=(int(i) for i in input().split())
print(max(o))
