l,o=map(int,input().split())
o=o-1
while(l<o):
  l=l+1
  if(l%2==0):
    print(l,'',end="")
