l=int(input())
o=5
g=0
u=1
for i in range(1,6):
  g=g+l
  print(g,"",end="")
