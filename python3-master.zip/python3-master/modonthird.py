l,o,g=map(int,input().split())
print(l*o%g)
