l=int(input())
o=1
temp=1
while o<=l:
  temp=temp*o
  o+=1
print(temp)
