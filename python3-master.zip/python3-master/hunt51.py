l,o=input().split()
l1=int(l)
l2=int(o)
m=l1*l2
o=str(m)
print(o)
