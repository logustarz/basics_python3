l,o=map(int,input().split())
logu=l**o
print(logu)
