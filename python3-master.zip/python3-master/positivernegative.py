xx=int(input())
if xx>0:
    print("Positive")
elif xx==0:
    print("Zero")
else:
    print("Negative")
