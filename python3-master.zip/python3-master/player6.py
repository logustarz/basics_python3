l,o=map(str,input().split())
x={}
y={}
def iso(l,o):
  if(len(l)!=len(o)):
      return False
  else:
        for i,v in enumerate(l):
            if v in x and x[v]!=o[i]:
                return False
            else:
                x[v]=o[i]
            if o[i] in y and y[o[i]]!=v:
                return False
            else:
                y[o[i]]=v
        return True
z=iso(l,o)
if(True==z):
    print("yes")
else:
    print("no")
