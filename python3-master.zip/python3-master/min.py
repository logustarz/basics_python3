l=int(input())
o=(int(i) for i in input().split())
print(min(o))
